#this script generates the count of the number of times each pinball trace needs to be repeated when merging pinballs
# This count is used by traces of all freqencies to merge the traces
#uses only the instruction count trace and generates the count as output
#the count must be generated corresponding to the highest frequency trace
#count is generated in the counts.json file which can be directly read in the next script


import numpy as np
import sys
import os
import json

FILENAME_IN_INSTR="instr.log"

FILENAME_OUT_RATIOS="counts.json"

#REQUIRED_LENGTH = int(sys.argv[1])
REQUIRED_LENGTH = 1000
BASE_COUNT = 100000             #since the weights are given as 5-digit number, they correspond to 100000

BENCHMARKS = ['exchange',
              'gcc',
              'imagick',
              'lbm',
              'nab',
              'x264',
              'mcf',
              'xalancbmk',
              'omnetpp'

             ]

combined_ratios={}

for bm in BENCHMARKS:
    weights = [d for d in os.listdir(bm) if os.path.isdir(bm+"/"+d)]   #directory names are as per weights
    print("Processing:",bm)
    total_count = 0                     #just used for checking
    ratios={}
    for w in weights:
        fname = str(bm) + "/" + str(w) + "/" + str(FILENAME_IN_INSTR)
        fp = open(fname, "r")
        traceLength = len(fp.readlines()) - 1       #exclude 1 as  first line is header
        fp.close()
        required_lines_of_file = int(w)/BASE_COUNT*REQUIRED_LENGTH
        #print(required_lines_of_file)
        required_ratio = required_lines_of_file / traceLength
        required_ratio = round(required_ratio, 3)
        total_count += required_lines_of_file
        ratios[w] = required_ratio
        #print(required_ratio)
    #print(ratios)
    combined_ratios[bm] = ratios
    total_count = round(total_count)

    if (total_count != REQUIRED_LENGTH):
        print("\n\n!! WARNING: Total count does not match the REQUIRED_LENGTH for %s !!" %bm)
        print("total count = %d, REQUIRED_LENGTH=%d \n\n" %(total_count, REQUIRED_LENGTH))

#print(combined_ratios)
print("Dumping json file %s" %FILENAME_OUT_RATIOS)
f = open(FILENAME_OUT_RATIOS, 'w')
json.dump(combined_ratios, f)
f.close()

#with open(FILENAME_OUT_RATIOS, 'r') as f:
#    data = json.load(f)    
#
#print(data)


