#!/bin/bash
#input arg contains the workloads directory path

scripts_dir=`pwd`
dirpath=$1
cd $dirpath

python3 $scripts_dir/combine_traces.py

cd workloads
for dir in `\ls`
do
    echo $dir
    cd $dir
    python3 $scripts_dir/gen_instr_count_cumulative.py
    mv instr.log instr_differential.log
    mv instr_pp.log instr.log
    cd ..
done

