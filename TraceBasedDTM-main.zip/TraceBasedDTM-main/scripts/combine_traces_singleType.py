#the script to combine the traces generated for single core from CoMeT for multiple cores and memory channels
#assumption is that the input traces have a single core and a single channel of memory (3Dmem arch.)
# the output repeats the single core/single channel values to NOF_CORE times
#generates 3 files for 3 inputs: instruction count trace, memory power trace, and core power trace


import numpy as np

NOF_CORE=16
NOF_CHANNELS=16
NOF_RANKS=128
LC_POWER=0.232

FILENAME_IN_INSTR="instr.log"
FILENAME_IN_CORE_POWER="full_power_core.trace"
FILENAME_IN_MEM_POWER="full_power_mem.trace"

FILENAME_OUT_INSTR="instr_out.log"
FILENAME_OUT_CORE_POWER="full_power_core_out.trace"
FILENAME_OUT_MEM_POWER="full_power_mem_out.trace"

OVERWRITE_LC_POWER = False

def combine_core(in_filename, out_filename, rounding=-1):
    fpi = open(in_filename, "r")
    fpo = open(out_filename, "w")
    fpi.readline()   #skip the first line (header)
    core_header = ""
    for i in range(0, NOF_CORE):
        core_header += "C_" + str(i) + "\t"
    fpo.write("%s\n" %(core_header))
    for content in fpi:
        core_header = ""
        content = content.rstrip()
        if (rounding!=-1):
            content = np.float64(content)
            content = np.round(content, rounding)
        for i in range(0, NOF_CORE):
            core_header += str(content) + "\t"
        fpo.write("%s\n" %(core_header))
    fpi.close()
    fpo.close()

def combine_memory(in_filename, out_filename, overwrite_lc, rounding=-1):
    fpi = open(in_filename, "r")
    fpo = open(out_filename, "w")
    fpi.readline()   #skip the first line (header)
    mem_header = ""
    for i in range(0, NOF_CHANNELS):
        mem_header += "LC_" + str(i) + "\t"
    for i in range(0, NOF_RANKS):
        mem_header += "B_" + str(i) + "\t"
    fpo.write("%s\n" %(mem_header))

    for content in fpi:
        mem_header = ""
        content = content.rstrip()
        content = content.split()
        for i in range(0, NOF_CHANNELS):
            if (overwrite_lc):
                mem_header += str(LC_POWER) + "\t"
            else:
                data = content[0]
                if (rounding!=-1):
                    data = np.float64(data)
                    data = np.round(data, rounding)
                mem_header += str(data) + "\t"

        for ind in range(0, NOF_RANKS):
            #repeat each column in input file NOF_CHANNELS number of times
            i = int(ind/NOF_CHANNELS) + 1             #increase by 1 as first index in input file is LC
            data = content[i]
            if (rounding!=-1):
                data = np.float64(data)
                data = np.round(data, rounding)
            mem_header += str(data) + "\t"

        fpo.write("%s\n" %(mem_header))
    fpi.close()
    fpo.close()



def main():
    combine_core(FILENAME_IN_INSTR, FILENAME_OUT_INSTR, -1)
    combine_core(FILENAME_IN_CORE_POWER, FILENAME_OUT_CORE_POWER, 4)
    combine_memory(FILENAME_IN_MEM_POWER, FILENAME_OUT_MEM_POWER, OVERWRITE_LC_POWER, 3)


if __name__ == "__main__" :    
    main()

