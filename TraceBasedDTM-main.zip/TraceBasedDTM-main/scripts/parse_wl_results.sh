#!/bin/bash

##usage ./parse_wl_results.sh <result_file_name>
##  example: ./run_wl.sh res.csv
##It will generate the csv file for each folder within the rundir. Also, a combined csv would be generated for all rundirs

#workloads=" egnm exch gcc gnml lbm mcf mmll nab x264 xxee "
workloads=" x264 xxee exch gcc nab egnm gnml mcf mmll lbm "

#rundirs=" rundir_proposed_73.0_80.1 rundir_proposed_73.0_80.1 rundir_proposed_73.0_73.0 rundir_baseline_73.0_73.0 "
rundirs=" rundir_proposed_80.1_80.1 rundir_baseline_80.1_80.1 rundir_proposed_80.1_73.0 rundir_baseline_80.1_73.0 rundir_proposed_73.0_80.1 rundir_baseline_73.0_80.1 rundir_proposed_73.0_73.0 rundir_baseline_73.0_73.0 "

res_file=$1
rm -f $res_file
echo ",,Core,,3D mem,,2D mem,,," >> $res_file
echo "Workload, Runtime, Dyn energy, Static energy, Dyn energy, Static energy, Dyn energy, Active time, Bandwidth needed" >> $res_file

#echo "Workload, Runtime, Core Dyn energy, Core Static energy, 3D Dyn energy, 3D Static energy, 2D Dyn energy, 2D Static energy" >> $res_file
for rundir_prefix in $rundirs
do
    res_file_local="$rundir_prefix/$res_file"
    rm -f $res_file_local
    echo ",,Core,,3D mem,,2D mem,," >> $res_file_local
    echo "Workload, Runtime, Dyn energy, Static energy, Dyn energy, Static energy, Dyn energy, Active time, Bandwidth needed" >> $res_file_local

    echo "$rundir_prefix" >> $res_file
    for wl in $workloads
    do
        rundir="$rundir_prefix/$wl"
        LC_leak_energy=`grep leakage_power_LC $rundir/logfile | awk -F"= " '{sum=sum+$2} END{print sum}'`
        Mem_leak_energy=`grep leakage_power_Bank $rundir/logfile | awk -F"= " '{sum=sum+$2} END{print sum}'`
        Core_leak_energy=`grep leakage_power_Core $rundir/logfile | awk -F "= " '{sum=sum+$2} END{print sum}'`
        LC_dyn_energy=`grep "Total LC dynamic energy" $rundir/logfile | awk '{print $6}'`
        Mem_dyn_energy=`grep "Total mem dynamic energy" $rundir/logfile | awk '{print $6}'`
        Core_dyn_energy=`grep "Total core dynamic energy" $rundir/logfile | awk '{print $6}'`
        Exec_time=`grep "Total time" $rundir/logfile | awk '{print $4}'`
        ThreeD_dyn_energy=`echo "$LC_dyn_energy + $Mem_dyn_energy" | bc`
        ThreeD_leak_energy=`echo "$LC_leak_energy + $Mem_leak_energy" | bc`
        if [[ $rundir_prefix == *"proposed"* ]]; then
            TwoD_dyn_energy=0
            TwoD_active_time=0
            TwoD_bandwidth=0
        else
            TwoD_dyn_energy=`grep "Total 2D mem dynamic energy" $rundir/logfile | awk '{print $7}'`
            TwoD_active_time=`grep "Total 2D mem active time" $rundir/logfile | awk '{print $7}'`
            TwoD_bandwidth=`grep "2D Memory Bandwidth Needed" $rundir/logfile | awk '{print $6}'`
        fi
    
        echo "$wl, $Exec_time, $Core_dyn_energy, $Core_leak_energy, $ThreeD_dyn_energy, $ThreeD_leak_energy, $TwoD_dyn_energy, $TwoD_active_time, $TwoD_bandwidth" >> $res_file_local
        echo "$wl, $Exec_time, $Core_dyn_energy, $Core_leak_energy, $ThreeD_dyn_energy, $ThreeD_leak_energy, $TwoD_dyn_energy, $TwoD_active_time, $TwoD_bandwidth" >> $res_file
    done        

    echo "" >> $res_file
done
