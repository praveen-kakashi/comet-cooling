#the script uses the existing traces to generate traces of a selected length, needed for weighing the pinballs
#the script uses previously generated counts for repeating a given trace and generates an updated trace.
#these updated traces are finally concatenated to form a final trace for the benchmark
#generates 3 files for 3 inputs: instruction count trace, memory power trace, and core power trace


import numpy as np
import sys
import json
import math

FILENAME_IN_INSTR="instr_pp.log"
FILENAME_IN_CORE_POWER="full_power_core.trace"
FILENAME_IN_MEM_POWER="full_power_mem.trace"

FILENAME_OUT_INSTR="instr_out.log"
FILENAME_OUT_CORE_POWER="full_power_core_out.trace"
FILENAME_OUT_MEM_POWER="full_power_mem_out.trace"

FILENAME_IN_COUNTS="../../../../counts.json"
#FILENAME_IN_COUNTS="../../../../counts.json"


def copy_trace(in_filename, out_filename, repeat_cnt):
    fpi = open(in_filename, "r")
    fpo = open(out_filename, "w")
    header = fpi.readline().rstrip()   #the first line (header)
    fpo.write("%s\n" %(header))         #write header as such

    content = fpi.readlines()
    traceLength = len(content)
    print("Trace length: %d" %(traceLength))
    
    integral_part = math.floor(repeat_cnt)
    fractional_part = repeat_cnt - integral_part
    print("Repeat count: %f" %(repeat_cnt))
    print("Integral part: %d, fractional part: %f" %(integral_part,fractional_part))
    output_content = []

    for i in range(0, integral_part):
        output_content = output_content + content

    #print(len(output_content))
    remaining_lines = fractional_part * traceLength
    remaining_lines = round(remaining_lines)
    #print(remaining_lines)
    if (remaining_lines!=0):            #if it is 0, it becomes content[-0:] and hence everything gets copied
        output_content = output_content + content[-remaining_lines:]

    print("Length of final trace: %d\n" %(len(output_content)))

    for c in output_content:
        fpo.write("%s" %(c))
    fpi.close()
    fpo.close()


def main():
    if (len(sys.argv) < 3):
        print("Error in arguments")
        print("Usage: %s <benchmark name> <folder name>" %(sys.argv[0]))
        exit()
    benchmark_name = sys.argv[1]
    folder_name = sys.argv[2]
    f=open(FILENAME_IN_COUNTS, 'r')
    countData = json.load(f)    
    f.close()
    try:
        repeat_count = countData[benchmark_name][folder_name]
    except:
        print("Key error in json file. Please check correctness of benchmark name and folder name")
        print("benchmark name supplied= %s, folder name supplied= %s" %(benchmark_name, folder_name))
        exit()
    print("Processing for instr count log")
    copy_trace(FILENAME_IN_INSTR, FILENAME_OUT_INSTR, repeat_count)
    print("Processing for core power trace")
    copy_trace(FILENAME_IN_CORE_POWER, FILENAME_OUT_CORE_POWER, repeat_count)
    print("Processing for memory power trace")
    copy_trace(FILENAME_IN_MEM_POWER, FILENAME_OUT_MEM_POWER, repeat_count)


if __name__ == "__main__" :    
    main()

