#the script creates traces for workloads containing mix of benchmarks
#the input contains set of benchmarks which form the workload. The benchmark names match the name of folders.
#reads the differential instr.log and identifies the trace with longest length.
#Line by line, prints the instr count from each log and wraps around if some trace gets completed.
#similar thing done for core power log.
#for memory power log trace file, merges LC first and then B0 of each, then B1, etc.
#generates 3 files for 3 inputs: instruction count trace, memory power trace, and core power trace


import numpy as np
import os

NOF_CORE=16
NOF_CHANNELS=16
NOF_RANKS=128
LC_POWER=0.232

FILENAME_IN_INSTR="instr.log"
FILENAME_IN_CORE_POWER="full_power_core.trace"
FILENAME_IN_MEM_POWER="full_power_mem.trace"

FILENAME_OUT_INSTR="instr.log"
FILENAME_OUT_CORE_POWER="full_power_core.trace"
FILENAME_OUT_MEM_POWER="full_power_mem.trace"

OVERWRITE_LC_POWER = False

#EDIT BELOW TO ADD NEW WORKLOADS
lbm=['lbm']*NOF_CORE
mcf=['mcf']*NOF_CORE
exch=['exchange']*NOF_CORE
gcc=['gcc']*NOF_CORE
#imag=['imagick']*NOF_CORE
nab=['nab']*NOF_CORE
#omne=['omnetpp']*NOF_CORE
x264=['x264']*NOF_CORE
#xala=['xalancbmk']*NOF_CORE
#lmeg=['lbm']*int(NOF_CORE/4) + ['mcf']*int(NOF_CORE/4) + ['exchange']*int(NOF_CORE/4) + ['gcc']*int(NOF_CORE/4)
xxee=['x264','exchange','x264','exchange','exchange','x264','exchange','x264','x264','exchange','x264','exchange','exchange','x264','exchange','x264']
egnm=['exchange','gcc','nab','mcf','mcf','exchange','gcc','nab','nab','mcf','exchange','gcc','gcc','nab','mcf','exchange']
gnml=['gcc','nab','mcf','lbm','nab','mcf','lbm','gcc','mcf','lbm','gcc','nab','gcc','nab','lbm','mcf']
mmll=['mcf','lbm','mcf','lbm','lbm','mcf','lbm','mcf','mcf','lbm','mcf','lbm','lbm','mcf','lbm','mcf']


#dict of workloads containing workload name and the list with its content
#workloads={'lbm':lbm, 'mcf':mcf, 'exch':exch, 'gcc':gcc, 'imag':imag, 'nab':nab, 'omne':omne, 'x264':x264, 'xala':xala, 'lmeg':lmeg}
workloads={'lbm':lbm, 'mcf':mcf, 'exch':exch, 'gcc':gcc, 'nab':nab, 'x264':x264, 'xxee':xxee, 'egnm':egnm, 'gnml':gnml, 'mmll':mmll}
#workloads={'lmeg':lmeg}


def combine_core(in_filename, out_filename, workload_name, rounding=-1):
    orig_traces=[]
    trace_lengths=[]
    for bm in workloads[workload_name]:
        #print(bm)
        in_file = bm + "/" + in_filename
        fpi = open(in_file, "r")
        fpi.readline()   #skip the first line (header)
        content = fpi.readlines()
        orig_traces.append(content)
        trace_lengths.append(len(content))
        fpi.close()
    #print(trace_lengths)

    out_file = "workloads/" + workload_name + "/" + out_filename
    fpo = open(out_file, "w")
    core_header = ""
    for i in range(0, NOF_CORE):
        core_header += "C_" + str(i) + "\t"
    fpo.write("%s\n" %(core_header))

    final_length = max(trace_lengths)           #trace with max. length is the length of combined trace
    for l in range(final_length):
        core_header = ""
        for i in range(NOF_CORE):
            trace_len = trace_lengths[i]
            trace_index = l%trace_len
            #print(trace_len, trace_index, l)
            content = orig_traces[i][trace_index]
            content = content.rstrip()
            if (rounding!=-1):
                content = np.float64(content)
                content = np.round(content, rounding)
            core_header += str(content) + "\t"
        fpo.write("%s\n" %(core_header))
    fpo.close()

def combine_memory(in_filename, out_filename, overwrite_lc, workload_name, rounding=-1):
    orig_traces=[]
    trace_lengths=[]
    for bm in workloads[workload_name]:
        #print(bm)
        in_file = bm + "/" + in_filename
        fpi = open(in_file, "r")
        fpi.readline()   #skip the first line (header)
        content = fpi.readlines()
        orig_traces.append(content)
        trace_lengths.append(len(content))
        fpi.close()
    #print(trace_lengths)

    out_file = "workloads/" + workload_name + "/" + out_filename
    fpo = open(out_file, "w")

    mem_header = ""
    for i in range(0, NOF_CHANNELS):
        mem_header += "LC_" + str(i) + "\t"
    for i in range(0, NOF_RANKS):
        mem_header += "B_" + str(i) + "\t"
    fpo.write("%s\n" %(mem_header))

    final_length = max(trace_lengths)           #trace with max. length is the length of combined trace
    for l in range(final_length):
        lc_data = np.zeros(NOF_CHANNELS, dtype=np.float64)
        bank_data = np.zeros(NOF_RANKS, dtype=np.float64)
        for i in range(NOF_CORE):
            trace_len = trace_lengths[i]
            trace_index = l%trace_len
            #print(trace_len, trace_index, l)
            content = orig_traces[i][trace_index]
            content = content.rstrip()
            content = content.split()
            if (overwrite_lc):
                lc_data[i] = LC_POWER
            else:
                data = content[0]
                if (rounding!=-1):
                    data = np.float64(data)
                    data = np.round(data, rounding)
                lc_data[i] = data

            #LC power added to array. Now process bank power
            NOF_LAYERS = int(NOF_RANKS/NOF_CHANNELS)
            for ind in range(0, NOF_LAYERS):
                #each column from input file needs to be scattered as per the bank numbering
                bank_index = i + ind*NOF_CHANNELS   #position in the final array
                content_index = ind + 1             #increase by 1 as first index in input file is LC
                data = content[content_index]
                if (rounding!=-1):
                    data = np.float64(data)
                    data = np.round(data, rounding)
                bank_data[bank_index] = data

        #create string from array for printing in trace format
        mem_data = ""
        for i in range(0, NOF_CHANNELS):
            mem_data += str(lc_data[i]) + "\t"
        for i in range(0, NOF_RANKS):
            mem_data += str(bank_data[i]) + "\t"
        fpo.write("%s\n" %(mem_data))

    fpo.close()

def main():
    if not os.path.exists("workloads"):
        os.mkdir("workloads")
    for wl in workloads.keys():
        dir_name = "workloads/" + wl
        if not os.path.exists(dir_name):
            os.mkdir(dir_name)
    for wl in workloads:
        print("Processing for workload: %s" %wl)
        combine_core(FILENAME_IN_INSTR, FILENAME_OUT_INSTR, wl, -1)
        combine_core(FILENAME_IN_CORE_POWER, FILENAME_OUT_CORE_POWER, wl, 4)
        combine_memory(FILENAME_IN_MEM_POWER, FILENAME_OUT_MEM_POWER, OVERWRITE_LC_POWER, wl, 3)


if __name__ == "__main__" :    
    main()

