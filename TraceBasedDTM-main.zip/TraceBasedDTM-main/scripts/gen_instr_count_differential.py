#this script reads the instr count log and converts it from a cumulative count to a differential count

import numpy as np

FILENAME_IN_INSTR="instr.log"
FILENAME_OUT_INSTR="instr_pp.log"

fpi = open(FILENAME_IN_INSTR, "r")
fpo = open(FILENAME_OUT_INSTR, "w")

header = fpi.readline().rstrip()     #skip the first line
fpo.write("%s\n" %(header))          #write the header as such into output file

prev_count = 0
for cumul_count in fpi:
    cumul_count = cumul_count.rstrip()
    cumul_count = np.uint64(cumul_count)
    diff_count = np.uint64(cumul_count - prev_count)
    prev_count = cumul_count
    diff_count = str(diff_count)
    fpo.write("%s\n" %(diff_count))
fpi.close()
fpo.close()

