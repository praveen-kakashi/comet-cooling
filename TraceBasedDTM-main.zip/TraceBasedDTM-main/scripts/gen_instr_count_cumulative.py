#this script reads the instr count log and converts it from a differential count to a cumulative count

import numpy as np

FILENAME_IN_INSTR="instr.log"
FILENAME_OUT_INSTR="instr_pp.log"
NOF_CORES = 16

fpi = open(FILENAME_IN_INSTR, "r")
fpo = open(FILENAME_OUT_INSTR, "w")

header = fpi.readline().rstrip()     #skip the first line
fpo.write("%s\n" %(header))          #write the header as such into output file

cumul_count = np.zeros(NOF_CORES, dtype=np.uint64)
diff_count = np.zeros(NOF_CORES, dtype=np.uint64)
for diff_count in fpi:
    diff_count = diff_count.rstrip()
    diff_count = diff_count.split()
    for i in range(len(diff_count)):
        diff_count[i] = int(diff_count[i])
    cumul_count = cumul_count + diff_count   #add two arrays together
    for c in cumul_count:
        fpo.write("%d\t" %(c))
    fpo.write("\n")
fpi.close()
fpo.close()

