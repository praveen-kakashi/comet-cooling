cd WorkArea_36
./run.sh &
cd ..

cd WorkArea_30
./run.sh &
cd ..

cd WorkArea_24
./run.sh &
cd ..

cd WorkArea_18
./run.sh &
cd ..

