## main script to invoke DTM and read traces
## arguments:
##    1. workload name
##    2. run directory (default=rundir)


##example python3 main.py arg1 arg2
import numpy as np
import os
import sys

np.set_printoptions(formatter={'float': lambda x: "{0:0.2f}".format(x)})

#  INPUTS:
#  
#  Instructions                     Core Power          
#  Active (HF)      LF                  Active  LF  
#  C1       C2      C1      C2          P1  P2  P1  P2
#  2001 2002    1501    1502        2.1 2.2 1.1 1.2
#  4001 4002    3001    3002        2.3 2.4 1.3 1.4
#  6001 6002    4501    4502        2.5 2.6 1.5 1.6
#  8001 8002    6001    6002        2.7 2.8 1.7 1.8
#  10001    10002   7501    7502        2.9 3.0 1.9 2.0
#                           
#  
#  Memory Power                         
#  Active (HF)                          LF
#  M1       M2      M3      M4          M1      M2      M3      M4
#  0.217    0.227   0.215   0.225       0.117   0.127   0.115   0.125
#  0.237    0.247   0.235   0.245       0.137   0.147   0.135   0.145
#  0.257    0.267   0.255   0.265       0.157   0.167   0.155   0.165
#  0.277    0.287   0.275   0.285       0.177   0.187   0.175   0.185
#  0.297    0.307   0.295   0.305       0.197   0.207   0.195   0.205
#                           
#  Temperatures                         
#  C1   C2      M1  M2  M3  M4      
#  74   75      75  77  67  65      
#  77   78      75  73  64  63      
#  79   77      76  74  66  64      
#  77   75      78  75  68  65      
#  75   77      75  77  69  67      
#                           
#  
#  OUTPUTS:
#                           
#  Core                         
#  States       Instructions        Power           
#  S1   S2      I1      I2          P1      P2      
#  A    A       2001    2002        2.1     2.2     
#  LF   LP      3001    2002        1.5     0.0     
#  LP   LF      3001    3002        0.0     1.6     
#  LP   A       3001    5002        0.0     2.5     
#  A    LP      5001    5002        2.4     0.0     
#                           
#  Memory Power                         
#  States               Power           
#  P0   P1  P2  P3      M1      M2      M3      M4
#  A    A   A   A       0.217   0.227   0.215   0.225
#  A    LP  A   LP      0.157   0.000   0.155   0.000
#  LP   A   LP  A       0.000   0.167   0.000   0.165
#  LP   A   LP  A       0.000   0.257   0.000   0.255
#  A    LP  A   LP      0.247   0.000   0.245   0.000


#Assumptions:
#    1. There is only whitespace between adjacent values in trace file (no comma or semicolon etc.)
#    2. The number of lines equal the NOF_TIMESTEP+1
#    3. The first line is ignored, assuming it is the header
#    4. The number of columns in instr trace and core power trace matches NOF_CORE
#    5. The number of columns in mem power trace matches NOF_RANKS
#    6. Any line which is fully blank is ignored


LC_POWER_VALUE = 0.272          # For 100% utilization LC Power  
MAX_CHANNEL_POWER = 2.468       # For 100% utilization total bank power (per channel)
CPKI_COMPUTE = 0.10             # Below 0.10 is compute intensive. CPKI - Channel power per kilo instuctions
CPKI_MEMORY = 0.65              # Above 0.65 is memory intensive. CPKI - Channel power per kilo instuctions


NOF_CORE_SETTINGS = 2 
NOF_CORE = 16
NOF_RANKS = 128
NOF_TIMESTEP = 5

#CORE_DTM_THRESHOLD_LP = 78.0


MEM_ACTIVE = 0
MEM_LOW_POWER = 1

CORE_ACTIVE = 0             #HF
CORE_F1 = 1                 #HF
CORE_F2 = 2                 #MF
CORE_F3 = 3                 #LF
CORE_LOW_POWER = 4

RANKS_PER_CHANNEL = 8
NOF_CHANNELS = int(NOF_RANKS/RANKS_PER_CHANNEL)

max_temperature_core = 0
k_DVFS = 2  # Epoch - 1
last_core = 0
N_RR_Core = 0
thermal_limit_core = float(sys.argv[3])
Freq_Downgrade = np.zeros(NOF_CORE)


max_temperature_Mem = 0
last_Mem = 0
N_RR_Mem = 0
thermal_limit_Mem = float(sys.argv[4])


CORE_DTM_THRESHOLD  = (thermal_limit_core - 4)    #decrease freq with rising temperature
MEM_DTM_THRESHOLD   = (thermal_limit_Mem - 4)


COMPUTE = 0 
MIXED = 1
MEMORY = 2
# 0 - compute
# 1 - mixed
# 2 - memory
# Intial value benchmark_type array. Dyanmically computed each epoch.
benchmark_type = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])     

WL_NAME=sys.argv[1]
try:
    RUNDIR=sys.argv[2]
except:
    RUNDIR="./rundir"       ##default run directory



#append should follow the order - from High to low modes
FILE_INSTR_TRACE = []
FILE_INSTR_TRACE.append("./Traces_1.8_2.4_3.0_3.6/WorkArea_3.6/workloads/"+WL_NAME+"/instr.log")
FILE_INSTR_TRACE.append("./Traces_1.8_2.4_3.0_3.6/WorkArea_3.0/workloads/"+WL_NAME+"/instr.log")
FILE_INSTR_TRACE.append("./Traces_1.8_2.4_3.0_3.6/WorkArea_2.4/workloads/"+WL_NAME+"/instr.log")
FILE_INSTR_TRACE.append("./Traces_1.8_2.4_3.0_3.6/WorkArea_1.8/workloads/"+WL_NAME+"/instr.log")

FILE_CORE_PWR_TRACE = []
FILE_CORE_PWR_TRACE.append("./Traces_1.8_2.4_3.0_3.6/WorkArea_3.6/workloads/"+WL_NAME+"/full_power_core.trace")
FILE_CORE_PWR_TRACE.append("./Traces_1.8_2.4_3.0_3.6/WorkArea_3.0/workloads/"+WL_NAME+"/full_power_core.trace")
FILE_CORE_PWR_TRACE.append("./Traces_1.8_2.4_3.0_3.6/WorkArea_2.4/workloads/"+WL_NAME+"/full_power_core.trace")
FILE_CORE_PWR_TRACE.append("./Traces_1.8_2.4_3.0_3.6/WorkArea_1.8/workloads/"+WL_NAME+"/full_power_core.trace")

FILE_MEM_PWR_TRACE = []
FILE_MEM_PWR_TRACE.append("./Traces_1.8_2.4_3.0_3.6/WorkArea_3.6/workloads/"+WL_NAME+"/full_power_mem.trace")
FILE_MEM_PWR_TRACE.append("./Traces_1.8_2.4_3.0_3.6/WorkArea_3.0/workloads/"+WL_NAME+"/full_power_mem.trace")
FILE_MEM_PWR_TRACE.append("./Traces_1.8_2.4_3.0_3.6/WorkArea_2.4/workloads/"+WL_NAME+"/full_power_mem.trace")
FILE_MEM_PWR_TRACE.append("./Traces_1.8_2.4_3.0_3.6/WorkArea_1.8/workloads/"+WL_NAME+"/full_power_mem.trace")

#FILE_CORE_TEMP_TRACE = "./Trace-Collaterals/HotSpot/full_temperature_core.trace"
#FILE_MEM_TEMP_TRACE = "./Trace-Collaterals/HotSpot/full_temperature_mem.trace"

#instruction_trace = np.empty((NOF_CORE_SETTINGS, NOF_TIMESTEP, NOF_CORE), dtype=np.uint64)
#core_power_trace = np.empty((NOF_CORE_SETTINGS, NOF_TIMESTEP, NOF_CORE), dtype=np.float64)
#memory_power_trace = np.empty((NOF_CORE_SETTINGS, NOF_TIMESTEP, NOF_RANKS), dtype=np.float64)
#core_temperature_trace = np.zeros((NOF_TIMESTEP, NOF_CORE), dtype=np.float64)
#memory_temperature_trace = np.zeros((NOF_TIMESTEP, NOF_RANKS), dtype=np.float64)
instruction_trace = []
core_power_trace = []
memory_power_trace = []
core_temperature_trace = []
memory_temperature_trace = []

core_freq = np.zeros((NOF_CORE), dtype=np.int32)                        #   0 - Highest Freq, 1 - Downgrade by 1
core_freq_rr = np.zeros((NOF_CORE), dtype=np.int32)                     #   0 - Highest Freq, 1 - Downgrade by 1

#core_state = np.zeros((NOF_TIMESTEP, NOF_CORE), dtype=np.uint32)
#memory_state = np.zeros((NOF_TIMESTEP, NOF_RANKS), dtype=np.uint32)
#memory_power = np.zeros((NOF_TIMESTEP, NOF_RANKS ), dtype=np.float64)
#LC_power = np.zeros((NOF_TIMESTEP, NOF_CHANNELS), dtype=np.float64)
#core_power = np.zeros((NOF_TIMESTEP, NOF_CORE), dtype=np.float64)
#instruction = np.zeros((NOF_TIMESTEP, NOF_CORE), dtype=np.uint64)
core_state = []
memory_state = []
memory_power = []
core_power = []
instruction = []
LC_power = []
memory_channel_power = np.zeros((NOF_CHANNELS), dtype=np.float64)

instr_goal=np.zeros(NOF_CORE, dtype=np.uint64)    
instr_executed=np.zeros(NOF_CORE, dtype=np.uint64)
core_done=np.zeros(NOF_CORE, dtype=bool)

core_dyn_energy=0.0
mem_dyn_energy=0.0
LC_dyn_energy=0.0

core_voltages = np.array([1.1, 1.0, 0.9, 0.8, 0.8])  #corresponding to ACTIVE, F1, F2, F3, and LOW POWER


DTYPE_INT = 0
DTYPE_FLOAT = 1

#The below routine reads files and extract data into a 2-D array
def read_and_extract_file(filename, dtype, skip_count=0):
    #print(filename)
    f = open(filename, "r")
    f.readline()    #Skip the first line
    file_content = []
    for content in f:
        content = content.rstrip()          #remove trailing whitespaces
        if (content == ''):                 #ignore blank lines
            continue
        instr = content.split()
        instr = instr[skip_count:]          #skip the first few entries, esp. for LC power
        #print(instr)
        for i in range(len(instr)):
            if dtype == DTYPE_INT:
                instr[i] = np.uint64(instr[i])
            elif dtype == DTYPE_FLOAT:
                instr[i] = np.float64(instr[i])
        file_content.append(instr)

    f.close()
    #print(file_content)
    return file_content


def find_instr (instr_count, core_id, core_status, instruction_trace):
    # print ("instr_count = %d, core_id = %d, core_status = %d" %(instr_count, core_id, core_status))
    #for i in range(0, NOF_TIMESTEP):
    length = len(instruction_trace[core_status])
    for i in range(0, length):
        nof_inst = instruction_trace[core_status][i][core_id]
        # print ("nof_inst = %d" %nof_inst)
        if (nof_inst > instr_count):
            break
    # print ("i = %d" %i)
    return max(0, i-1) #return 0 in case of negative numbers

def none(timestep):
    # print ("zero Start")

    for x in range(NOF_CORE):
        if not(benchmark_type[x] == 2):  
            # Heated_Core[x] = 0
            Freq_Downgrade[x] = 0   # High Freq
            core_state[timestep][x] = CORE_ACTIVE
        # else: # For Memory
        #     print("Memory")

    print ("Freq_Downgrade," , Freq_Downgrade)

    # print ("zero Done")
 


def dtm_core(timestep):
    # print ("one Start"

    # print ("\n")    

    global long_term_avg_core_temperature
    global avg_k_core_temperature

    avg_temperature_core = np.average(core_temperature_trace[timestep])
    # print ("avg_temperature_core," , '%.2f'%(avg_temperature_core))


    if (not(timestep % k_DVFS)):
    # timestep % k_DVFS = 0 => Time for DVFS
        print ("Core DVFS")
        if not(timestep):
            # print ("First time")
            # long_term_avg_core_temperature = core_temperature_trace[0]
            avg_k_core_temperature = [0.0]*NOF_CORE
            max_k_core_temperature = [0.0]*NOF_CORE
        else:

            core_temperature_trace_sum_k = core_temperature_trace[timestep-(k_DVFS-1)]
            max_k_core_temperature = core_temperature_trace[timestep-(k_DVFS-1)]
            # print (timestep-(k_DVFS-1))
            # print (core_temperature_trace_sum_k)

            for x in range(1, k_DVFS-1):
                #print (x)
                # print (timestep - x)
                # print (core_temperature_trace[timestep - x])
                core_temperature_trace_sum_k = core_temperature_trace_sum_k + core_temperature_trace[timestep - x]
                max_k_core_temperature = np.maximum(max_k_core_temperature, core_temperature_trace[timestep - x])

            avg_k_core_temperature = (core_temperature_trace_sum_k + core_temperature_trace[timestep-(k_DVFS)])/k_DVFS
            max_k_core_temperature = np.maximum(max_k_core_temperature, core_temperature_trace[timestep-(k_DVFS)])

            # core_temperature_trace_sum_k = core_temperature_trace_sum_k + core_temperature_trace[timestep]
            # long_term_avg_core_temperature = long_term_avg_core_temperature * (timestep-(k_DVFS-1)) + core_temperature_trace_sum_k
            # long_term_avg_core_temperature = long_term_avg_core_temperature/(timestep+1)

        #print (long_term_avg_core_temperature)
        
        # print (avg_k_core_temperature)
        print ("max_k_core_temperature, " , max_k_core_temperature)


        Heated_Core = np.zeros(NOF_CORE)
        

        for x in range(NOF_CORE):
            Heated_Core[x] = 1
            if (max_k_core_temperature[x] >= thermal_limit_core):
                Freq_Downgrade[x] = 16
            elif (max_k_core_temperature[x] >= (thermal_limit_core -0.5)):
                Freq_Downgrade[x] = 3
            elif (max_k_core_temperature[x] >= (thermal_limit_core -1.0)):
                Freq_Downgrade[x] = 2
            elif (max_k_core_temperature[x] >= (thermal_limit_core -1.5)):
                Freq_Downgrade[x] = 1
            elif (max_k_core_temperature[x] >= (thermal_limit_core -2.0)):
                Freq_Downgrade[x] = 1
            elif (max_k_core_temperature[x] >= (thermal_limit_core -2.5)):
                Freq_Downgrade[x] = 1
            elif (max_k_core_temperature[x] >= (thermal_limit_core -3.0)):
                Freq_Downgrade[x] = 1
            elif (max_k_core_temperature[x] >= (thermal_limit_core -3.5)):
                Freq_Downgrade[x] = 1
            elif (max_k_core_temperature[x] >= (thermal_limit_core -4.0)):
                Freq_Downgrade[x] = 1
            else:
                if not(benchmark_type[x] == 2):    
                    Freq_Downgrade[x] = 0
                    Heated_Core[x] = 0          


        x = 0
        while x < NOF_CORE:
            core_freq[x] = Freq_Downgrade[x]
            x = x + 1

        print ("Freq_Downgrade, " , Freq_Downgrade)



    print ("Core Round Robin")
    # print ("max_temperature_core, " , '%.2f'%max_temperature_core)
    if (max_temperature_core >= thermal_limit_core):
        N_RR_Core = 16
    elif (max_temperature_core >= (thermal_limit_core -0.5)):
        N_RR_Core = 3
    elif (max_temperature_core >= (thermal_limit_core -1.0)):
        N_RR_Core = 2
    elif (max_temperature_core >= (thermal_limit_core -1.5)):
        N_RR_Core = 1
    elif (max_temperature_core >= (thermal_limit_core -2.0)):
        N_RR_Core = 1
    elif (max_temperature_core >= (thermal_limit_core -2.5)):
        N_RR_Core = 1
    elif (max_temperature_core >= (thermal_limit_core -3.0)):
        N_RR_Core = 1
    elif (max_temperature_core >= (thermal_limit_core -3.5)):
        N_RR_Core = 1
    elif (max_temperature_core >= (thermal_limit_core -4.0)):
        N_RR_Core = 1
    else:    
        N_RR_Core = 0

    global last_core


    if (timestep == 0):
        # Make all active
        x = 0
        while x < NOF_CORE:
            core_freq[x] = 0                # High Freq  
            core_freq_rr[x] = 0             # High Freq  
            x = x + 1
    else:
        # Intializing core_freq_rr at each invocation
        x = 0
        while x < NOF_CORE:
            core_freq_rr[x] = core_freq[x]
            x = x + 1


    if (avg_temperature_core < (max_temperature_core - 1.0)):
        if (N_RR_Core > 0):
            #print ("Update")
            N_RR_Core = N_RR_Core - 1


    print ("Core RR List", end = ', ')
    # Round-Robin Freq. reduction
    i = last_core
    x = 0
    while x < N_RR_Core:
        # print(i,end ='')
        print(i, end = ', ')
        core_freq_rr[i] = core_freq_rr[i] + 1   # Downgrade by 1
        i = (i+1)%NOF_CORE
        x = x + 1

    last_core = i



    # Frequency to state-mapping
    # CORE_LOW_POWER could also be used later
    x = 0
    while x < NOF_CORE:
        
        if (core_freq_rr[x] == 0):
            core_state[timestep][x] = CORE_ACTIVE
        elif (core_freq_rr[x] == 1):
            core_state[timestep][x] = CORE_F1
        elif (core_freq_rr[x] == 2):
            core_state[timestep][x] = CORE_F2
        elif (core_freq_rr[x] == 3):
            core_state[timestep][x] = CORE_F3
        else:
            core_state[timestep][x] = CORE_F3

        x = x + 1



    print ("")
    # return "one Done"

def dtm_mem(timestep):
    # print ("two Start")

    sort_index = np.argsort(memory_temperature_trace[timestep][0:NOF_CHANNELS])
    rev_sort_index = sort_index[::-1]
    print ("rev_sort_index, " , rev_sort_index)

    print ("Mem Round Robin")
    print ("max_temperature_Mem," , '%.2f'%max_temperature_Mem)
    if (max_temperature_Mem >= thermal_limit_Mem):
        N_RR_Mem = 16
    elif (max_temperature_Mem >= (thermal_limit_Mem -0.5)):
        N_RR_Mem = 5
    elif (max_temperature_Mem >= (thermal_limit_Mem -1.0)):
        N_RR_Mem = 1
    elif (max_temperature_Mem >= (thermal_limit_Mem -1.5)):
        N_RR_Mem = 0
    elif (max_temperature_Mem >= (thermal_limit_Mem -2.0)):
        N_RR_Mem = 0
    elif (max_temperature_Mem >= (thermal_limit_Mem -2.5)):
        N_RR_Mem = 0
    elif (max_temperature_Mem >= (thermal_limit_Mem -3.0)):
        N_RR_Mem = 0
    elif (max_temperature_Mem >= (thermal_limit_Mem -3.5)):
        N_RR_Mem = 0
    elif (max_temperature_Mem >= (thermal_limit_Mem -4.0)):
        N_RR_Mem = 0
    else:    
        N_RR_Mem = 0

    global last_Mem

    # print ("Mem RR List", end = ', ')
    # Make all active
    x = 0
    while x < NOF_CHANNELS:
        memory_state[timestep][x] = MEM_ACTIVE
        x = x + 1


    # Convert state to low-power
    # i = last_Mem
    # x = 0
    # while x < N_RR_Mem:
    #     # print(i,end ='')
    #     print(i, end = ', ')
    #     memory_state[timestep][i] = MEM_LOW_POWER
    #     i = (i+1)%NOF_CHANNELS
    #     x = x + 1

    # last_Mem = i


    print ("\nNew Mem RR List", end = ', ')
    x = 0
    while x < N_RR_Mem:
        # print(i,end ='')
        i = rev_sort_index[x]
        print(i, end = ', ')
        memory_state[timestep][i] = MEM_LOW_POWER
        x = x + 1


    print ("")
    # return "two Done"


def both(timestep):
    # print ("three Start")

    slack_core = thermal_limit_core - max_temperature_core
    slack_Mem = thermal_limit_Mem - max_temperature_Mem

    if (slack_core<slack_Mem):
        dtm_core(timestep)
    else:
        dtm_mem(timestep)

    # print ("three Done")

switcher = {
        0: none,
        1: dtm_core,
        2: dtm_mem,
        3: both
    }
 
 
def dtm(argument,timestep):
    # Get the function from switcher dictionary
    func = switcher.get(argument, "nothing")
    # Execute the function
    return func(timestep)
 
#  Reads the temperature
#  Selects the state
#  
#  
#  Assuming first time its called timestep is 1
#Limitations:
# 1. Frequency upgrade code? only  downgrade is present now.
# 2. Number of steps
# 3. First time invocation of dtm and thermal calc. - dependency b/w temp and power
# 4. Assumption that #cores = #channels

def dtm_policy(timestep):
    # Core DTM to determine core_state
    #print(timestep)
    global core_state, core_power, memory_state, memory_power, instruction, max_temperature_core, max_temperature_Mem, LC_power
    global instr_executed
    memory_state.append(np.zeros(NOF_RANKS, dtype=np.uint32))
    core_state.append(np.zeros(NOF_CORE, dtype=np.uint32))
    memory_power.append(np.zeros(NOF_RANKS, dtype=np.float64))
    core_power.append(np.zeros(NOF_CORE, dtype=np.float64))
    instruction.append(np.zeros(NOF_CORE, dtype=np.uint64))
    LC_power.append(np.zeros(NOF_CHANNELS, dtype=np.float64))


    # for i in range(0, NOF_CORE):
    #     if (core_temperature_trace[timestep][i] >= CORE_DTM_THRESHOLD_LP):
    #         core_state[i][timestep] = CORE_LOW_POWER
    #     elif (core_temperature_trace[timestep][i] >= CORE_DTM_THRESHOLD):
    #         core_state[i][timestep] = CORE_F1
    #     else:
    #         core_state[i][timestep] = CORE_ACTIVE

    # # Channel level policy (Memory) to determine memory_state
    # for i in range(0, NOF_CHANNELS):
    #     if (memory_temperature_trace[timestep][i] >= MEM_DTM_THRESHOLD):
    #         memory_state[i][timestep] = MEM_LOW_POWER
    #     else:
    #         memory_state[i][timestep] = MEM_ACTIVE

    # print ("")
    # print (timestep)

    # Determining core and memory states based on temperature
    print ("core_temperature, " , core_temperature_trace[timestep])
    max_temperature_core = np.max(core_temperature_trace[timestep])
    print ("max_temperature_core, " , max_temperature_core)

    
    print ("memory_temperature, " , memory_temperature_trace[timestep][0:NOF_CHANNELS])
    max_temperature_Mem = np.max(memory_temperature_trace[timestep])
    print ("max_temperature_Mem, " , max_temperature_Mem)

    if ((max_temperature_core >= CORE_DTM_THRESHOLD) and (max_temperature_Mem >= MEM_DTM_THRESHOLD)):
        print ("Both Heated")
        dtm(3,timestep)
    elif (max_temperature_core >= CORE_DTM_THRESHOLD):
        print ("Core Heated")
        dtm(1,timestep)
    elif (max_temperature_Mem >= MEM_DTM_THRESHOLD):
        print ("Mem Heated")
        dtm(2,timestep)
    else:
        print ("None Heated")
        dtm(0,timestep)

    # Assuming one memory channel per core
    for i in range(0, NOF_CORE):
        if (core_done[i] == True):                  ##if benchmark is already completed
            core_state[timestep][i] = CORE_LOW_POWER

        if (memory_state[timestep][i] == MEM_LOW_POWER):
            core_state[timestep][i] = CORE_LOW_POWER
            continue    
        if (core_state[timestep][i] == CORE_LOW_POWER):
            memory_state[timestep][i] = MEM_LOW_POWER
            continue
    

    # Replicating memory channel state to all the ranks
    for i in range(NOF_CHANNELS, NOF_RANKS):
        channel_number = i%NOF_CHANNELS
        memory_state[timestep][i] = memory_state[timestep][channel_number]

    # Final instruction, power assignement to core
    for i in range(0, NOF_CORE):
        c_state = core_state[timestep][i]
        i_count = 0
        # c_power = 0     #added temporarily
        if (timestep == 0):
            c_state_prev = CORE_ACTIVE
            i_count_prev = 0
        else:
            c_state_prev = core_state[timestep-1][i]
            i_count_prev = instruction[timestep-1][i]

        if (c_state == CORE_LOW_POWER):
            i_count = i_count_prev
            c_power = 0
        else:
            if (i_count_prev == 0):
                i_count = instruction_trace[c_state][0][i]
                c_power = core_power_trace[c_state][0][i]
            else:
                # print ("Calling find_instr for CORE")
                t_step = find_instr (i_count_prev, i, c_state, instruction_trace)
                trace_length = len(instruction_trace[c_state])
                if (t_step <= (trace_length - 3)):
                    i1 = instruction_trace[c_state][t_step][i]
                    i2 = instruction_trace[c_state][t_step+1][i]
                    i3 = instruction_trace[c_state][t_step+2][i]
                    # print ("i_count_prev = %d, i1 = %d, i2 = %d, i3 = %d" %(i_count_prev, i1, i2, i3))
                    ## print("start")
                    ## print(t_step)
                    ## print(i_count_prev)
                    ## print(i3)
                    ## print(i2)
                    ## print(i1)
                    ## print((i_count_prev - i1)*(i3 - i2))
                    ## i_count = np.uint64 (np.uint64 (i2) + ( np.uint64( np.uint64(i_count_prev - i1) * np.uint64(i3 - i2) ) / np.uint64(i2 - i1) ))
                    if (i_count_prev < i1):
                        if (t_step == 0):
                            i1 = 0
                            i2 = instruction_trace[c_state][t_step][i]
                            i3 = instruction_trace[c_state][t_step+1][i]

                    i_count = i2 + ( ( (i_count_prev - i1) * (i3 - i2) ) / (i2 - i1) )
            # p1 = core_power_trace[c_state][i][t_step];
                    p2 = core_power_trace[c_state][t_step+1][i]
                    p3 = core_power_trace[c_state][t_step+2][i]
                    # print ("p2 = %0.2f, p3 = %0.2f" %(p2, p3))

                    if (i_count_prev < i1):
                        if (t_step == 0):
                            p2 = core_power_trace[c_state][t_step][i]
                            p3 = core_power_trace[c_state][t_step+1][i]

                    c_power = ( ( p2 *  (i2 - i_count_prev) ) + ( p3 *  (i_count_prev - i1) ) ) / (i2 - i1)
                #what happens to c_power on else condition
                else:
                    i1 = instruction_trace[c_state][t_step][i]
                    i2 = instruction_trace[c_state][t_step-1][i]
                    i_count = i_count_prev + (i1-i2)
                    c_power = core_power_trace[c_state][t_step][i]
                    # print ("i_count_prev = %d, t_step = %d, i1 = %d, i2 = %d, i_count =%d, c_power= %0.2f" %(i_count_prev, t_step,i1,i2,i_count,c_power))


        instruction[timestep][i] = i_count
        instr_executed[i] = i_count
        core_power[timestep][i] = round(c_power,1)

    #assumption that #cores = #channels
    #Power assignement to memory
    for i in range(0, NOF_RANKS):
        channel_number = i%NOF_CHANNELS
        mem_state = memory_state[timestep][channel_number]
        c_state = core_state[timestep][channel_number]
        if (timestep == 0):
            i_count_prev = 0
        else:
            i_count_prev = instruction[timestep-1][channel_number]
        
        if (mem_state == MEM_LOW_POWER):
            memory_power[timestep][i] = 0
            memory_channel_power[channel_number] = 0
            LC_power[timestep][channel_number] = 0
        else:
            if (i_count_prev == 0):
                memory_power[timestep][i] = memory_power_trace[c_state][0][i]
            else:
                # print ("Calling find_instr for MEMORY")
                t_step = find_instr (i_count_prev, channel_number, c_state, instruction_trace)
                trace_length = len(instruction_trace[c_state])
                if (t_step <= (trace_length - 3)):
                    i1 = instruction_trace[c_state][t_step][channel_number]
                    i2 = instruction_trace[c_state][t_step+1][channel_number]
                    # print ("i_count_prev = %d, i1 = %d, i2 = %d" %(i_count_prev, i1, i2))
                    p2 = memory_power_trace[c_state][t_step+1][i]
                    p3 = memory_power_trace[c_state][t_step+2][i]
                    # print ("p2 = %0.4f, p3 = %0.4f" %(p2, p3))

                    if (i_count_prev < i1):
                        if (t_step == 0):
                            i1 = 0
                            i2 = instruction_trace[c_state][t_step][channel_number]
                            p2 = memory_power_trace[c_state][t_step][i]
                            p3 = memory_power_trace[c_state][t_step+1][i]

                    memory_power[timestep][i] = ( ( p2 *  (i2 - i_count_prev) ) + ( p3 *  (i_count_prev - i1) ) ) / (i2 - i1)
                else:
                    memory_power[timestep][i] = memory_power_trace[c_state][t_step][i]


            if (i < NOF_CHANNELS):
                memory_channel_power[channel_number] = memory_power[timestep][i]
            else:    
                memory_channel_power[channel_number] = memory_channel_power[channel_number] + memory_power[timestep][i]
            
            memory_power[timestep][i] = round(memory_power[timestep][i],3)
            LC_power[timestep][channel_number] = np.round(LC_POWER_VALUE * (memory_channel_power[channel_number]/MAX_CHANNEL_POWER),3)

        
    
    for i in range(0, NOF_CHANNELS):
        benchmark_type[i] = MIXED

        if (memory_state[timestep][i] == MEM_LOW_POWER):
            benchmark_type[i] = MIXED
        else:

            if (timestep == 0):
                i_count_prev = 0
            else:
                i_count_prev = instruction[timestep-1][i]

            i1 = instruction[timestep][i] - i_count_prev
            if (i1 <= 0):
                benchmark_type[i] = MIXED
            else:
                p1 = memory_channel_power[i]
                cpki = 1000000* p1/i1
                # print ("i1 = %d, p1 = %0.4f, cpki = %0.4f" %(i1, p1, cpki))
                if (cpki < CPKI_COMPUTE):
                    benchmark_type[i] = COMPUTE
                else:
                    if (cpki > CPKI_MEMORY):
                        benchmark_type[i] = MEMORY
                    else:
                        benchmark_type[i] = MIXED

    print ("benchmark_type, " , benchmark_type)
    print ("core_state, " , core_state[timestep])
    print ("memory_state, " , memory_state[timestep][0:NOF_CHANNELS])
    print ("core_power, " , core_power[timestep])
    print ("bottom_rank_power, " , memory_power[timestep][0:NOF_CHANNELS])



    # print (benchmark_type)



    # for i in range(0, NOF_RANKS):
    #     channel_number = i%NOF_CHANNELS

        # print ("i = %d, memory_channel_power[%d] = %0.4f" %(i, channel_number, memory_channel_power[channel_number]))



# creates a power trace file. Currently, it is in the format for 3Dmem architecture.
# the trace file is separate for core power and for memory power (LC and Banks)
def create_power_trace_file(timestep, c_power_trace_file, power_trace_file):
    global core_dyn_energy, LC_dyn_energy, mem_dyn_energy

    core_header = ""
    for i in range(0, NOF_CORE):
        core_header += "C_" + str(i) + "\t"
    fcore = open("%s" %(c_power_trace_file), "w")
    fcore.write("%s\n" %(core_header))
    #write power values now
    core_header = ""
    for i in range(0, NOF_CORE):
        if (timestep == 0):
            core_header += str(0.0) + "\t"
        else:
            core_header += str(core_power[timestep-1][i]) + "\t"
            core_dyn_energy += core_power[timestep-1][i]

    # print("core power")            
    # print("%s\n" %(core_header))
    fcore.write("%s\n" %(core_header))
    fcore.close()

    mem_header = ""
    for i in range(0, NOF_CHANNELS):
        mem_header += "LC_" + str(i) + "\t"
    for i in range(0, NOF_RANKS):
        mem_header += "B_" + str(i) + "\t"
    fmem = open("%s" %(power_trace_file), "w")
    fmem.write("%s\n" %(mem_header))
    #write power values now
    mem_header = ""
    for i in range(0, NOF_CHANNELS):
        # mem_header += str(LC_POWER_VALUE) + "\t"
        if (timestep == 0):
            mem_header += str(0.0) + "\t"
        else:
            mem_header += str(LC_power[timestep-1][i]) + "\t"
            LC_dyn_energy += LC_power[timestep-1][i]
    for i in range(0, NOF_RANKS):
        if (timestep == 0):
            mem_header += str(0.0) + "\t"
        else:
            mem_header += str(memory_power[timestep-1][i]) + "\t"
            mem_dyn_energy += memory_power[timestep-1][i]
    
    # print("memory power")    
    # print("%s\n" %(mem_header[NOF_CHANNELS:]))
    # print(memory_power[timestep-1])
    fmem.write("%s\n" %(mem_header))
    fmem.close()


# reads temperature trace from the hotspot generated trace file and puts in appropriate array
def read_temperature_trace_file(timestep, c_temperature_trace_file, temperature_trace_file):
    global core_temperature_trace, memory_temperature_trace
    core_temperature_trace.append(np.zeros(NOF_CORE, dtype=np.float64))
    memory_temperature_trace.append(np.zeros(NOF_RANKS, dtype=np.float64))

    fcore = open("%s" %(c_temperature_trace_file), "r")
    fcore.readline()        #ignore header line
    core_line = fcore.readline()
    fcore.close()
    core_line = core_line.rstrip()          #remove trailing whitespaces
    core_line = core_line.split()
    for i in range(len(core_line)):
        core_temperature_trace[timestep][i] = np.float64(core_line[i])

    fmem = open("%s" %(temperature_trace_file), "r")
    fmem.readline()        #ignore header line
    mem_line = fmem.readline()
    fmem.close()
    mem_line = mem_line.rstrip()          #remove trailing whitespaces
    mem_line = mem_line.split()
    mem_line = mem_line[NOF_CHANNELS:]      #Skip first few entries corresponding to LC
    for i in range(len(mem_line)):
        memory_temperature_trace[timestep][i] = np.float64(mem_line[i])

    #print (core_temperature_trace, memory_temperature_trace)

# assumption is that the srcfile has only 2 lines.
# first line is header and second line is data which needs to be appended in dstfile
# if timestep=0, we copy the header and data to dstfile, else only the data
def append_file(srcFile, destFile, timestep):
    fpSrc = open(srcFile, "r")
    fpDst = open(destFile, "a")
    if (timestep == 0):
        fpDst.write(fpSrc.readline())       #write header
        fpDst.write(fpSrc.readline())       #write the trace
    else:
        fpSrc.readline()            #skip first line/header
        fpDst.write(fpSrc.readline())
    fpSrc.close()
    fpDst.close()


def run_thermal_sim(timestep):
    power_trace_file = RUNDIR+"/power_mem.trace"
    full_power_trace_file = RUNDIR+"/full_power_mem.trace"
    executable = "./hotspot_tool/hotspot"
    hotspot_config_file = "./config/3Dmem_16core/mem_hotspot.config"
    temperature_trace_file = RUNDIR+"/temperature_mem.trace"
    full_temperature_trace_file = RUNDIR+"/full_temperature_mem.trace"
    hotspot_steady_temp_file = RUNDIR+"/steady_temp_mem.log"
    hotspot_all_transient_file = RUNDIR+"/all_transient_mem.log"
    hotspot_grid_steady_file = RUNDIR+"/grid_steady_mem.log"
    type_of_stack = "3Dmem"
    interval_sec = 0.001
    hotspot_layer_file = "./config/3Dmem_16core/mem.lcf"
    vdd_string = "1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1"
    init_file_orig = "./config/3Dmem_16core/mem.init"
    init_file = RUNDIR+"/mem.init"

    c_power_trace_file = RUNDIR+"/power_core.trace"
    c_full_power_trace_file = RUNDIR+"/full_power_core.trace"
    c_executable = "./hotspot_tool/hotspot"
    c_hotspot_config_file = "./config/3Dmem_16core/cores_hotspot.config"
    c_temperature_trace_file = RUNDIR+"/temperature_core.trace"
    c_full_temperature_trace_file = RUNDIR+"/full_temperature_core.trace"
    c_hotspot_steady_temp_file = RUNDIR+"/steady_temp_core.log"
    c_hotspot_all_transient_file = RUNDIR+"/all_transient_core.log"
    c_hotspot_grid_steady_file = RUNDIR+"/grid_steady_core.log"
    c_type_of_stack = "Core"
    c_interval_sec = 0.001
    c_hotspot_layer_file = "./config/3Dmem_16core/cores.lcf"
    c_init_file_orig = "./config/3Dmem_16core/cores.init"
    c_init_file = RUNDIR+"/cores.init"


    if(timestep == 0):
        os.system("mkdir -p "+RUNDIR)
        os.system("cp -f " + c_init_file_orig + " " + c_init_file)
        os.system("cp -f " + init_file_orig + " " + init_file)
        os.system("rm -f full_temperature_trace_file")
        os.system("rm -f full_power_trace_file")
        os.system("rm -f c_full_temperature_trace_file")
        os.system("rm -f c_full_power_trace_file")
        leakage_string_mem = "1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,"
        leakage_string_core = "1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,"
        c_vdd_string = "1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1"
    else:
        leakage_string_mem = ""
        leakage_string_core = ""
        c_vdd_string = ""
        # return

    create_power_trace_file(timestep, c_power_trace_file, power_trace_file)
    #assign leakage vector to pass to hotspot.
    if(timestep > 0):
        for i in range(NOF_CORE):
            if (core_state[timestep-1][i] == CORE_LOW_POWER):
                leakage_string_core += "0,"
            else:
                leakage_string_core += "1,"
            vdd_factor = core_voltages[core_state[timestep-1][i]]
            c_vdd_string += str(vdd_factor) + ","
        for i in range(NOF_CHANNELS):
            if (memory_state[timestep-1][i] == MEM_LOW_POWER):
                leakage_string_mem += "0,"
            else:
                leakage_string_mem += "1,"
    #print(leakage_string_mem, leakage_string_core)
    #print("Leakage string core:%s" %(leakage_string_core))
    #print("Leakage string memory:%s" %(leakage_string_mem))

    hotspot_command = executable  \
                  + ' -c ' + hotspot_config_file \
                  + ' -p ' + power_trace_file \
                  + ' -o ' + temperature_trace_file \
                  + ' -model_secondary 1 -model_type grid ' \
                  + ' -steady_file ' + hotspot_steady_temp_file \
                  + ' -all_transient_file ' + hotspot_all_transient_file \
                  + ' -grid_steady_file ' + hotspot_grid_steady_file \
                  + ' -steady_state_print_disable 1 ' \
                  + ' -l ' + leakage_string_mem \
                  + ' -type ' + type_of_stack \
                  + ' -sampling_intvl ' + str(interval_sec) \
                  + ' -grid_layer_file ' + hotspot_layer_file \
                  + ' -detailed_3D on' \
                  + ' -v ' + vdd_string \
                  + ' -init_file ' + init_file
    
    #print("core vdd string:%s" %c_vdd_string)
    c_hotspot_command = c_executable  \
                  + ' -c ' + c_hotspot_config_file \
                  + ' -p ' + c_power_trace_file \
                  + ' -o ' + c_temperature_trace_file \
                  + ' -model_secondary 1 -model_type grid ' \
                  + ' -steady_file ' + c_hotspot_steady_temp_file \
                  + ' -all_transient_file ' + c_hotspot_all_transient_file \
                  + ' -grid_steady_file ' + c_hotspot_grid_steady_file \
                  + ' -steady_state_print_disable 1 ' \
                  + ' -l ' + leakage_string_core \
                  + ' -type ' + c_type_of_stack \
                  + ' -sampling_intvl ' + str(c_interval_sec) \
                  + ' -grid_layer_file ' + c_hotspot_layer_file \
                  + ' -detailed_3D on' \
                  + ' -v ' + c_vdd_string \
                  + ' -init_file ' + c_init_file

    os.system(hotspot_command)
    os.system("cp -f " + hotspot_all_transient_file + " " + init_file)

    os.system(c_hotspot_command)
    os.system("cp -f " + c_hotspot_all_transient_file + " " + c_init_file)

    read_temperature_trace_file(timestep, c_temperature_trace_file, temperature_trace_file)
    append_file(power_trace_file, full_power_trace_file, timestep)
    append_file(c_power_trace_file, c_full_power_trace_file, timestep)
    append_file(temperature_trace_file, full_temperature_trace_file, timestep)
    append_file(c_temperature_trace_file, c_full_temperature_trace_file, timestep)

#check that all cores are completed their goals
def check_termination():
    global core_done
    done=True
    #for i in range(NOF_CORE):
    #    print(instr_executed[i], instr_goal[i])
    for i in range(NOF_CORE):
        if (instr_executed[i] >= instr_goal[i]):
            core_done[i] = True
        else:
            core_done[i] = False
            done = False
    #print(done)
    return done

#calculate the minimum number of instructions for each benchmark
#this will be the target goal for each core to achieve
def get_instr_goal(instruction_traces):
    last_instr_count=[]
    min_instr_count=[]
    for i in range(len(instruction_traces)):
        last_instr_count.append(instruction_traces[i][-1])
    last_instr_count = np.transpose(last_instr_count)   #transpose for easy calculation using min
    #print(last_instr_count)
    for i in range(NOF_CORE):
        min_instr_count.append(min(last_instr_count[i]))
    return min_instr_count

#main entry point of the function
def main():
    timestep = 0
    #global core_temperature_trace, memory_temperature_trace
    global instruction_trace, core_power_trace, memory_power_trace
    global instr_goal

#    instruction_trace[CORE_ACTIVE] = (read_and_extract_file(FILE_INSTR_TRACE[CORE_ACTIVE], DTYPE_INT)).copy()
#    instruction_trace[CORE_F1] = (read_and_extract_file(FILE_INSTR_TRACE[CORE_F1], DTYPE_INT)).copy()
#    #print (instruction_trace)
#    core_power_trace[CORE_ACTIVE] = (read_and_extract_file(FILE_CORE_PWR_TRACE[CORE_ACTIVE], DTYPE_FLOAT)).copy()
#    core_power_trace[CORE_F1] = (read_and_extract_file(FILE_CORE_PWR_TRACE[CORE_F1], DTYPE_FLOAT)).copy()
#    #print (core_power_trace)
#    memory_power_trace[CORE_ACTIVE] = (read_and_extract_file(FILE_MEM_PWR_TRACE[CORE_ACTIVE], DTYPE_FLOAT, NOF_CHANNELS)).copy()
#    memory_power_trace[CORE_F1] = (read_and_extract_file(FILE_MEM_PWR_TRACE[CORE_F1], DTYPE_FLOAT, NOF_CHANNELS)).copy()
#    #print (memory_power_trace)
    instruction_trace.append((read_and_extract_file(FILE_INSTR_TRACE[CORE_ACTIVE], DTYPE_INT)).copy())
    instruction_trace.append((read_and_extract_file(FILE_INSTR_TRACE[CORE_F1], DTYPE_INT)).copy())    
    instruction_trace.append((read_and_extract_file(FILE_INSTR_TRACE[CORE_F2], DTYPE_INT)).copy())    
    instruction_trace.append((read_and_extract_file(FILE_INSTR_TRACE[CORE_F3], DTYPE_INT)).copy())    
    instr_goal = get_instr_goal(instruction_trace)
    #print (instruction_trace)
    core_power_trace.append((read_and_extract_file(FILE_CORE_PWR_TRACE[CORE_ACTIVE], DTYPE_FLOAT)).copy())
    core_power_trace.append((read_and_extract_file(FILE_CORE_PWR_TRACE[CORE_F1], DTYPE_FLOAT)).copy())
    core_power_trace.append((read_and_extract_file(FILE_CORE_PWR_TRACE[CORE_F2], DTYPE_FLOAT)).copy())
    core_power_trace.append((read_and_extract_file(FILE_CORE_PWR_TRACE[CORE_F3], DTYPE_FLOAT)).copy())
    #print (core_power_trace)
    memory_power_trace.append((read_and_extract_file(FILE_MEM_PWR_TRACE[CORE_ACTIVE], DTYPE_FLOAT, NOF_CHANNELS)).copy())
    memory_power_trace.append((read_and_extract_file(FILE_MEM_PWR_TRACE[CORE_F1], DTYPE_FLOAT, NOF_CHANNELS)).copy())
    memory_power_trace.append((read_and_extract_file(FILE_MEM_PWR_TRACE[CORE_F2], DTYPE_FLOAT, NOF_CHANNELS)).copy())
    memory_power_trace.append((read_and_extract_file(FILE_MEM_PWR_TRACE[CORE_F3], DTYPE_FLOAT, NOF_CHANNELS)).copy())
    #print (memory_power_trace)
        # skip NOF_CHANNELS to skip the LC entries in memory power trace. Applicable for 3Dmem
    #core_temperature_trace = (read_and_extract_file(FILE_CORE_TEMP_TRACE, DTYPE_FLOAT)).copy()
    ##print (core_temperature_trace)
    #memory_temperature_trace = (read_and_extract_file(FILE_MEM_TEMP_TRACE, DTYPE_FLOAT)).copy()
    ##print (memory_temperature_trace)

    #exit()

    print("thermal_limit_core=%f" %(thermal_limit_core))
    print("thermal_limit_Mem=%f" %(thermal_limit_Mem))
    print("k_DVFS=%d" %(k_DVFS))
    
#    for j in range(0, NOF_TIMESTEP):
    # while(timestep < 200):
    while(True):

        print ("")
        print ("")
        print("Processing Time step=%d" %(timestep))
        
    # Inputs of the DTM (Instruction trace, Power trace, Temperature)
    # Outputs of the DTM (State, Instruction numbers, Power)
        #print(instr_executed)
        #print(instr_goal)
        #print(core_done)
        if (check_termination()):
            break

        run_thermal_sim(timestep)
        dtm_policy(timestep)
    # Increase time step counter
        timestep = timestep + 1;
        #if (timestep == 10):
        #    break

    print ("")
    print ("")
    print("Total time = %d units (ms)" %(timestep))
    print("Total core dynamic energy = %.2f units (mJ)" %(core_dyn_energy))
    print("Total LC dynamic energy = %.2f units (mJ)" %(LC_dyn_energy))
    print("Total mem dynamic energy = %.2f units (mJ)" %(mem_dyn_energy))


if __name__ == "__main__" :    
    main()
