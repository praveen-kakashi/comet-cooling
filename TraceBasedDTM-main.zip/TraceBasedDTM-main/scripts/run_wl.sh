#!/bin/bash

##usage ./run_wl.sh <python script type> <run directory prefix> <core_limit as float> <mem_limit as float> <nthreads> 
##      nthreads=1 for sequential version and more than 1 for concurrent execution
##  example: ./scripts/run_wl.sh proposed rundir 73.0 80.2 2

workloads=" egnm exch gcc gnml lbm mcf mmll nab x264 xxee "

script_type=$1
rundir_prefix=$2
core_limit=$3
memory_limit=$4
maxThreads=$5

script_name="main_$1.py"

parallel_function() {
    ##Concurrently run the workloads with $maxThreads at a time
    ##beta version, might have errors
    echoList=""
    for wl in $workloads
    do
        rundir="${rundir_prefix}_${script_type}_${core_limit}_${memory_limit}"
        rundir="$rundir/$wl"
        mkdir -p $rundir
        #echo "Setting workload: $wl, rundir = $rundir"
        echoList="${echoList} ${script_name} $wl $rundir $core_limit $memory_limit"
    done        
    sleep 1
    echo "Combined list=$echoList"
    echo ""
    ##below command indicates that the main.py script takes 4 arguments at a time, and we want to run $maxThreads threads at a time.
    ##the argments are treated as $0, $1, $2, $3 by xargs
    ##5 args are: $0 - python script name, $1 - wl name, $2 - rundir, $3 - core limit, $4 - memory limit
    echo $echoList | xargs -n 5 -P $maxThreads sh -c 'echo "Running workload: $1, rundir: $2"; python3 $0 $1 $2 $3 $4 > $2/logfile 2>&1; echo "Completed workload: $1"'
    ##for debugging
    #echo $echoList | xargs -n 4 -P $maxThreads sh -c 'echo "python3 main.py $0 $1 $2 $3 > $1/logfile 2>&1"'
}
##end of parallel_function


serial_function() {
##Sequentially run the workloads one after another
    for wl in $workloads
    do
        rundir="${rundir_prefix}_${script_type}_${core_limit}_${memory_limit}"
        rundir="$rundir/$wl"
        mkdir -p $rundir
        mkdir -p $rundir
        echo "Running workload: $wl, rundir = $rundir"
        python3 $script_name $wl $rundir $core_limit $memory_limit > $rundir/logfile 2>&1
        echo "Completed workload: $wl"
    done        
}
##end of serial function


#main function begins here
if [ "$maxThreads" -gt 1 ]            #if p is specified, execute parallel.
then
    echo "executing parallel version"
    parallel_function
else
    echo "executing serial version"
    serial_function         #default to serial function
fi
    

