# TraceBasedDTM
A trace based setup for dynamic thermal management

Instructions to run the flow with default traces:

1. Clone the repo
2. Update the SuperLUroot variable in SuperLU directory (see filename: make.inc) to your appropriate directories
3. Run make in the SuperLU. You might get error to install csh. Do by sudo apt-get install csh. Also, if you get -lblas related error, please do sudo apt-get install liblapack-dev liblapack3 libopenblas-base libopenblas-dev
4. cd hotspot_tool
5. Build hotspot using "make SUPERLU=1" command in the hotspot_tool folder
6. cd ../
7. Execute: python3 main_proposed.py mcf rundir 73.0 80.1 > /tmp/t


Executing post processing scripts:

1. Processing all output traces by merging various pinballs

   ./run_tracegen.sh <Trace directory path>

      e.g., ./run_tracegen.sh ../Traces_1.8_2.4_3.0_3.6/WorkArea_1.8
   
   It is assumed that the Workarea is within the traces directory

2. Generating counts.json:
   
   From the workarea of 3.6 GHz freq., execute the following command:
   
      python3 ../scripts/gen_pinball_repeat_counts.py

3. Generating workloads:
    From the script directory, execute the following. List of workloads is a part of the combine_traces.py script
    
    ./workloads.sh <Trace directory path>

      e.g., ./workloads.sh ../Traces_1.8_2.4_3.0_3.6/WorkArea_1.8

