declare -a arr_exchange=(
    "benchmarks/exchange/exchange2.new_27410_t0r1_warmup101500_prolog0_region100000005_epilog0_001_0-07095.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r2_warmup101500_prolog0_region100000007_epilog0_002_0-06759.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r3_warmup101500_prolog0_region100000000_epilog0_003_0-03132.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r4_warmup101500_prolog0_region100000036_epilog0_004_0-02952.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r5_warmup101500_prolog0_region100000011_epilog0_005_0-01625.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r6_warmup101500_prolog0_region100000016_epilog0_006_0-06752.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r7_warmup101500_prolog0_region100000012_epilog0_007_0-09808.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r8_warmup101500_prolog0_region100000001_epilog0_008_0-07707.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r9_warmup101500_prolog0_region100000002_epilog0_009_0-07771.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r10_warmup101500_prolog0_region100000007_epilog0_010_0-01683.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r11_warmup101500_prolog0_region100000003_epilog0_011_0-03805.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r12_warmup101500_prolog0_region100000001_epilog0_012_0-04305.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r13_warmup101500_prolog0_region100000005_epilog0_013_0-09022.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r14_warmup101500_prolog0_region100000003_epilog0_014_0-02978.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r15_warmup101500_prolog0_region100000001_epilog0_015_0-07299.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r16_warmup101500_prolog0_region100000000_epilog0_016_0-03038.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r17_warmup101500_prolog0_region100000006_epilog0_017_0-03697.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r18_warmup101500_prolog0_region100000008_epilog0_018_0-09624.0.address"
    "benchmarks/exchange/exchange2.new_27410_t0r19_warmup101500_prolog0_region100000002_epilog0_019_0-00945.0.address"
)

declare -a arr_x264=(
    "benchmarks/x264/x264.test_19842_t0r1_warmup1501_prolog0_region100000003_epilog0_001_0-10829.0.address"
    "benchmarks/x264/x264.test_19842_t0r2_warmup1501_prolog0_region100000028_epilog0_002_0-00468.0.address"
    "benchmarks/x264/x264.test_19842_t0r3_warmup1501_prolog0_region100000005_epilog0_003_0-16543.0.address"
    "benchmarks/x264/x264.test_19842_t0r4_warmup1501_prolog0_region100000018_epilog0_004_0-05694.0.address"
    "benchmarks/x264/x264.test_19842_t0r5_warmup1501_prolog0_region100000009_epilog0_005_0-04043.0.address"
    "benchmarks/x264/x264.test_19842_t0r6_warmup1501_prolog0_region100000008_epilog0_006_0-01171.0.address"
    "benchmarks/x264/x264.test_19842_t0r7_warmup1501_prolog0_region100000004_epilog0_007_0-01082.0.address"
    "benchmarks/x264/x264.test_19842_t0r8_warmup1501_prolog0_region100000006_epilog0_008_0-14943.0.address"
    "benchmarks/x264/x264.test_19842_t0r9_warmup1501_prolog0_region100000007_epilog0_009_0-03995.0.address"
    "benchmarks/x264/x264.test_19842_t0r10_warmup1501_prolog0_region100000005_epilog0_010_0-00959.0.address"
    "benchmarks/x264/x264.test_19842_t0r11_warmup1501_prolog0_region100000012_epilog0_011_0-12324.0.address"
    "benchmarks/x264/x264.test_19842_t0r12_warmup1501_prolog0_region100000026_epilog0_012_0-12034.0.address"
    "benchmarks/x264/x264.test_19842_t0r13_warmup1501_prolog0_region100000011_epilog0_013_0-03169.0.address"
    "benchmarks/x264/x264.test_19842_t0r14_warmup1501_prolog0_region100000042_epilog0_014_0-12742.0.address"
)

declare -a arr_gcc=(
    "benchmarks/gcc/gcc.try_33001_t0r1_warmup101500_prolog0_region100000004_epilog0_001_0-00871.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r2_warmup101500_prolog0_region100000001_epilog0_002_0-23620.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r3_warmup101500_prolog0_region100000001_epilog0_003_0-01363.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r4_warmup101500_prolog0_region100000007_epilog0_004_0-12001.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r5_warmup101500_prolog0_region100000000_epilog0_005_0-00092.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r6_warmup101500_prolog0_region100000004_epilog0_006_0-00444.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r7_warmup101500_prolog0_region100000015_epilog0_007_0-00685.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r8_warmup101500_prolog0_region100000012_epilog0_008_0-00361.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r9_warmup101500_prolog0_region100000007_epilog0_009_0-00842.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r10_warmup101500_prolog0_region100000003_epilog0_010_0-00168.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r11_warmup101500_prolog0_region100000000_epilog0_011_0-03596.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r12_warmup101500_prolog0_region100000004_epilog0_012_0-00822.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r13_warmup101500_prolog0_region100000010_epilog0_013_0-05280.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r14_warmup101500_prolog0_region100000007_epilog0_014_0-01207.0.address"
    "benchmarks/gcc/gcc.try_33001_t0r15_warmup101500_prolog0_region100000013_epilog0_015_0-48648.0.address"
)

declare -a arr_nab=(
    "benchmarks/nab/nab.try_6816_t0r1_warmup101500_prolog0_region100000000_epilog0_001_0-00160.0.address"
    "benchmarks/nab/nab.try_6816_t0r2_warmup101500_prolog0_region100000052_epilog0_002_0-00262.0.address"
    "benchmarks/nab/nab.try_6816_t0r3_warmup101500_prolog0_region100000019_epilog0_003_0-07451.0.address"
    "benchmarks/nab/nab.try_6816_t0r4_warmup101500_prolog0_region100000022_epilog0_004_0-00140.0.address"
    "benchmarks/nab/nab.try_6816_t0r5_warmup101500_prolog0_region100000008_epilog0_005_0-06907.0.address"
    "benchmarks/nab/nab.try_6816_t0r6_warmup101500_prolog0_region100000010_epilog0_006_0-22748.0.address"
    "benchmarks/nab/nab.try_6816_t0r7_warmup101500_prolog0_region100000001_epilog0_007_0-00086.0.address"
    "benchmarks/nab/nab.try_6816_t0r8_warmup101500_prolog0_region100000005_epilog0_008_0-00080.0.address"
    "benchmarks/nab/nab.try_6816_t0r9_warmup101500_prolog0_region100000017_epilog0_009_0-34240.0.address"
    "benchmarks/nab/nab.try_6816_t0r10_warmup101500_prolog0_region100000012_epilog0_010_0-09763.0.address"
    "benchmarks/nab/nab.try_6816_t0r11_warmup101500_prolog0_region100000061_epilog0_011_0-00251.0.address"
    "benchmarks/nab/nab.try_6816_t0r12_warmup101500_prolog0_region100000017_epilog0_012_0-17913.0.address"
)

declare -a arr_imagick=(
    "benchmarks/imagick/imagick.try_31938_t0r1_warmup101500_prolog0_region100000018_epilog0_001_0-00035.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r2_warmup101500_prolog0_region100000003_epilog0_002_0-01267.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r3_warmup101500_prolog0_region100000007_epilog0_003_0-04235.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r4_warmup101500_prolog0_region100000001_epilog0_004_0-04967.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r5_warmup101500_prolog0_region100000019_epilog0_005_0-00783.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r6_warmup101500_prolog0_region100000014_epilog0_006_0-27234.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r7_warmup101500_prolog0_region100000000_epilog0_007_0-00041.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r8_warmup101500_prolog0_region100000001_epilog0_008_0-01211.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r9_warmup101500_prolog0_region100000004_epilog0_009_0-00035.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r10_warmup101500_prolog0_region100000001_epilog0_010_0-02756.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r11_warmup101500_prolog0_region100000009_epilog0_011_0-08117.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r12_warmup101500_prolog0_region100000001_epilog0_012_0-02448.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r13_warmup101500_prolog0_region100000002_epilog0_013_0-02500.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r14_warmup101500_prolog0_region100000018_epilog0_014_0-43830.0.address"
    "benchmarks/imagick/imagick.try_31938_t0r15_warmup101500_prolog0_region100000005_epilog0_015_0-00539.0.address"
)

declare -a arr_lbm=(
    "benchmarks/lbm/lbm.try_30208_t0r1_warmup101500_prolog0_region100000007_epilog0_001_0-14923.0.address"
    "benchmarks/lbm/lbm.try_30208_t0r2_warmup101500_prolog0_region100000030_epilog0_002_0-00559.0.address"
    "benchmarks/lbm/lbm.try_30208_t0r3_warmup101500_prolog0_region100000006_epilog0_003_0-03648.0.address"
    "benchmarks/lbm/lbm.try_30208_t0r4_warmup0_prolog0_region100000002_epilog0_004_0-00013.0.address"
    "benchmarks/lbm/lbm.try_30208_t0r5_warmup101500_prolog0_region100000026_epilog0_005_0-02382.0.address"
    "benchmarks/lbm/lbm.try_30208_t0r6_warmup101500_prolog0_region100000009_epilog0_006_0-04426.0.address"
    "benchmarks/lbm/lbm.try_30208_t0r7_warmup101500_prolog0_region100000040_epilog0_007_0-04356.0.address"
    "benchmarks/lbm/lbm.try_30208_t0r8_warmup101500_prolog0_region100000059_epilog0_008_0-69692.0.address"
)


declare -a arr_xalancbmk=(
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r1_warmup1501_prolog0_region100000001_epilog0_001_0-01812.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r2_warmup1501_prolog0_region100000003_epilog0_002_0-03884.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r3_warmup1501_prolog0_region100000001_epilog0_003_0-00175.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r4_warmup1501_prolog0_region100000003_epilog0_004_0-05795.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r5_warmup1501_prolog0_region100000000_epilog0_005_0-11134.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r6_warmup1501_prolog0_region100000001_epilog0_006_0-06770.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r7_warmup1501_prolog0_region100000009_epilog0_007_0-01637.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r8_warmup1501_prolog0_region100000000_epilog0_008_0-04409.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r9_warmup1501_prolog0_region100000000_epilog0_009_0-01637.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r10_warmup1501_prolog0_region100000000_epilog0_010_0-10517.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r11_warmup1501_prolog0_region100000001_epilog0_011_0-00358.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r12_warmup1501_prolog0_region100000000_epilog0_012_0-12474.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r13_warmup1501_prolog0_region100000002_epilog0_013_0-05163.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r14_warmup1501_prolog0_region100000002_epilog0_014_0-01721.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r15_warmup1501_prolog0_region100000001_epilog0_015_0-04737.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r16_warmup1501_prolog0_region100000000_epilog0_016_0-08347.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r17_warmup1501_prolog0_region100000006_epilog0_017_0-02620.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r18_warmup1501_prolog0_region100000001_epilog0_018_0-02597.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r19_warmup1501_prolog0_region100000002_epilog0_019_0-07623.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r20_warmup1501_prolog0_region100000000_epilog0_020_0-02490.0.address"
    "benchmarks/xalancbmk/xalancbmk.test_563_t0r21_warmup1501_prolog0_region100000001_epilog0_021_0-04097.0.address"
)

declare -a arr_mcf=(
    "benchmarks/mcf/MCF.test_26448_t0r1_warmup11500_prolog0_region100000000_epilog0_001_0-12543.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r2_warmup11500_prolog0_region100000000_epilog0_002_0-00067.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r3_warmup11500_prolog0_region100000003_epilog0_003_0-00415.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r4_warmup11500_prolog0_region100000000_epilog0_004_0-02116.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r5_warmup11500_prolog0_region100000004_epilog0_005_0-06044.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r6_warmup11500_prolog0_region100000000_epilog0_006_0-00191.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r7_warmup11500_prolog0_region100000001_epilog0_007_0-07688.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r8_warmup11500_prolog0_region100000011_epilog0_008_0-00269.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r9_warmup11500_prolog0_region100000000_epilog0_009_0-03401.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r10_warmup11500_prolog0_region100000004_epilog0_010_0-05135.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r11_warmup11500_prolog0_region100000000_epilog0_011_0-03361.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r12_warmup11500_prolog0_region100000041_epilog0_012_0-06970.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r13_warmup11500_prolog0_region100000000_epilog0_013_0-10820.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r14_warmup11500_prolog0_region100000002_epilog0_014_0-00498.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r15_warmup11500_prolog0_region100000005_epilog0_015_0-10753.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r16_warmup11500_prolog0_region100000003_epilog0_016_0-02015.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r17_warmup11500_prolog0_region100000019_epilog0_017_0-00925.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r18_warmup11500_prolog0_region100000004_epilog0_018_0-21241.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r19_warmup11500_prolog0_region100000001_epilog0_019_0-02245.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r20_warmup11500_prolog0_region100000001_epilog0_020_0-02408.0.address"
    "benchmarks/mcf/MCF.test_26448_t0r21_warmup11500_prolog0_region100000002_epilog0_021_0-00892.0.address"
)


declare -a arr_omnetpp=(
    "benchmarks/omnetpp/omnetpp.try_39148_t0r1_warmup101500_prolog0_region100000002_epilog0_001_0-06547.0.address"
    "benchmarks/omnetpp/omnetpp.try_39148_t0r2_warmup101500_prolog0_region100000014_epilog0_002_0-00509.0.address"
    "benchmarks/omnetpp/omnetpp.try_39148_t0r3_warmup101500_prolog0_region100000005_epilog0_003_0-30324.0.address"
    "benchmarks/omnetpp/omnetpp.try_39148_t0r4_warmup101500_prolog0_region100000001_epilog0_004_0-09002.0.address"
    "benchmarks/omnetpp/omnetpp.try_39148_t0r5_warmup101500_prolog0_region100000003_epilog0_005_0-00055.0.address"
    "benchmarks/omnetpp/omnetpp.try_39148_t0r6_warmup101500_prolog0_region100000005_epilog0_006_0-15248.0.address"
    "benchmarks/omnetpp/omnetpp.try_39148_t0r7_warmup101500_prolog0_region100000003_epilog0_007_0-32560.0.address"
)


declare -a arr_leela=(
    #"benchmarks/leela/leela.try_33426_t0r1_warmup101500_prolog0_region100000002_epilog0_001_0-02657.0.address"
    #"benchmarks/leela/leela.try_33426_t0r2_warmup101500_prolog0_region100000000_epilog0_002_0-00040.0.address"
    #"benchmarks/leela/leela.try_33426_t0r3_warmup101500_prolog0_region100000001_epilog0_003_0-00979.0.address"
    #"benchmarks/leela/leela.try_33426_t0r4_warmup101500_prolog0_region100000003_epilog0_004_0-01598.0.address"
    #"benchmarks/leela/leela.try_33426_t0r5_warmup101500_prolog0_region100000001_epilog0_005_0-03098.0.address"
    #"benchmarks/leela/leela.try_33426_t0r6_warmup101500_prolog0_region100000003_epilog0_006_0-03445.0.address"
    #"benchmarks/leela/leela.try_33426_t0r7_warmup101500_prolog0_region100000002_epilog0_007_0-02502.0.address"
    #"benchmarks/leela/leela.try_33426_t0r8_warmup101500_prolog0_region100000015_epilog0_008_0-04171.0.address"
    #"benchmarks/leela/leela.try_33426_t0r9_warmup101500_prolog0_region100000002_epilog0_009_0-05488.0.address"
    #"benchmarks/leela/leela.try_33426_t0r10_warmup101500_prolog0_region100000004_epilog0_010_0-01914.0.address"
    #"benchmarks/leela/leela.try_33426_t0r11_warmup101500_prolog0_region100000004_epilog0_011_0-00961.0.address"
    #"benchmarks/leela/leela.try_33426_t0r12_warmup101500_prolog0_region100000003_epilog0_012_0-04286.0.address"
    #"benchmarks/leela/leela.try_33426_t0r13_warmup101500_prolog0_region100000004_epilog0_013_0-03365.0.address"
    #"benchmarks/leela/leela.try_33426_t0r14_warmup101500_prolog0_region100000007_epilog0_014_0-05644.0.address"
    #"benchmarks/leela/leela.try_33426_t0r15_warmup101500_prolog0_region100000062_epilog0_015_0-02025.0.address"
    #"benchmarks/leela/leela.try_33426_t0r16_warmup101500_prolog0_region100000001_epilog0_016_0-06850.0.address"
    #"benchmarks/leela/leela.try_33426_t0r17_warmup101500_prolog0_region100000005_epilog0_017_0-01148.0.address"
    #"benchmarks/leela/leela.try_33426_t0r18_warmup101500_prolog0_region100000006_epilog0_018_0-08626.0.address"
    #"benchmarks/leela/leela.try_33426_t0r19_warmup101500_prolog0_region100000000_epilog0_019_0-02395.0.address"
    #"benchmarks/leela/leela.try_33426_t0r20_warmup101500_prolog0_region100000000_epilog0_020_0-07149.0.address"
    #"benchmarks/leela/leela.try_33426_t0r21_warmup101500_prolog0_region100000004_epilog0_021_0-03592.0.address"
    #"benchmarks/leela/leela.try_33426_t0r22_warmup101500_prolog0_region100000061_epilog0_022_0-06565.0.address"
    #"benchmarks/leela/leela.try_33426_t0r23_warmup101500_prolog0_region100000002_epilog0_023_0-06748.0.address"
    #"benchmarks/leela/leela.try_33426_t0r24_warmup101500_prolog0_region100000001_epilog0_024_0-01838.0.address"
    #"benchmarks/leela/leela.try_33426_t0r25_warmup101500_prolog0_region100000000_epilog0_025_0-01358.0.address"
    #"benchmarks/leela/leela.try_33426_t0r26_warmup101500_prolog0_region100000000_epilog0_026_0-02519.0.address"
    #"benchmarks/leela/leela.try_33426_t0r27_warmup101500_prolog0_region100000026_epilog0_027_0-03672.0.address"
    #"benchmarks/leela/leela.try_33426_t0r28_warmup101500_prolog0_region100000014_epilog0_028_0-03895.0.address"
    #"benchmarks/leela/leela.try_33426_t0r29_warmup101500_prolog0_region100000056_epilog0_029_0-01469.0.address"
)

run_benchmark () {
   
   i="$1"         # Save first argument in a variable
   shift          # Shift all arguments to the left (original $1 gets lost)
   arr_b=("$@")   # Rebuild the array with rest of arguments

   #echo "RUNNING $i simpoints."
   ## now loop through the above array
   for SIM_PATH in "${arr_b[@]}"
   do
      # echo "$SIM_PATH"
      SIM_PATH="../../../$SIM_PATH"
      # echo "$SIM_PATH"
      var=`echo "$SIM_PATH" | cut -d'-' -f 2 | cut -d '.' -f 1`
      echo "$var"
      echo "Check $i/$var/log"
      mkdir $var
      cd $var
      # ls -lrt .
      #../../../../../run-sniper -v -s memTherm_core -c gainestown_3Dmem -n 4 --pinballs $SIM_PATH,$SIM_PATH,$SIM_PATH,$SIM_PATH > log
      ../../../../../run-sniper -v -s memTherm_core -s instrTrace -c gainestown_3Dmem_1core_1ch_18 -n 1 --pinballs $SIM_PATH > log
      cd ..
   done
}

declare -a arr=(
"exchange"
"x264"
"gcc"
"nab"
"imagick"
"lbm"
"mcf"
"omnetpp"
# "leela"
"xalancbmk"
)


for i in "${arr[@]}"
do
   echo "$i"
   mkdir $i 
   cd $i
   # ls -lrt .


   if [ "$i" = "exchange" ]; then
      run_benchmark $i "${arr_exchange[@]}"
   fi

   if [ "$i" = "x264" ]; then
      run_benchmark $i "${arr_x264[@]}"
   fi

   if [ "$i" = "gcc" ]; then
      run_benchmark $i "${arr_gcc[@]}"
   fi

   if [ "$i" = "nab" ]; then
      run_benchmark $i "${arr_nab[@]}"
   fi

   if [ "$i" = "imagick" ]; then
      run_benchmark $i "${arr_imagick[@]}"
   fi

   if [ "$i" = "lbm" ]; then
      run_benchmark $i "${arr_lbm[@]}"
   fi
   
   if [ "$i" = "mcf" ]; then
      run_benchmark $i "${arr_mcf[@]}"
   fi

   if [ "$i" = "omnetpp" ]; then
      run_benchmark $i "${arr_omnetpp[@]}"
   fi

   if [ "$i" = "leela" ]; then
      run_benchmark $i "${arr_leela[@]}"
   fi

   if [ "$i" = "xalancbmk" ]; then
      run_benchmark $i "${arr_xalancbmk[@]}"
   fi

   cd ..
done
